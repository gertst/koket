_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

    TSP100 Sample Program of Get Printer Status for Visual C++

                                                 Since     2011/02/16

_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

================
  Introduction
================
This sample program provides you to the function to get the printer status
of Star TSP100 series POS Printer.

This sample program offers you its source file, so that you can use it as
you like for your software.


==========================
  Installation and usage
==========================

// Models

  Folder of TSP100ECO : TSP113U   / TSP143U   / TSP143ECO
  Folder of TSP100GT  : TSP113GT  / TSP143GT
  Folder of TSP100LAN : TSP113LAN / TSP143LAN


// Sample Programs

  Run the "GetStatus.exe". (64bit: GetStatus_x64.exe)

  Each sample program use default printer queue name.
  When you change your printer queue name, please change queue name which
  you named, instead of default queue name.

  e.g. If the printer queue name is "Star TSP100 Cutter_1",
       "GetStatus.cpp", line 17 will be below. (*1)

       #define TSP100_PRINTER_NAME     _T("Star TSP100 Cutter_1")


      (*1): The printer queue name is a printer name in "Printers and Faxes"
            folder.


  NOTE: In case of using Windows7 and Vista, please run sample program as a
        administrator.


=============
  Copyright
=============
 (C)Star Micronics Co., Ltd. All rights reserved.

