﻿namespace VirtualSerialPortSample_dotNet
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonSend = new System.Windows.Forms.Button();
            this.labelPort = new System.Windows.Forms.Label();
            this.comboBoxPorts = new System.Windows.Forms.ComboBox();
            this.groupBoxLog = new System.Windows.Forms.GroupBox();
            this.buttonClear = new System.Windows.Forms.Button();
            this.textBoxLog = new System.Windows.Forms.TextBox();
            this.comboBoxFlowControl = new System.Windows.Forms.ComboBox();
            this.labelFlowControl = new System.Windows.Forms.Label();
            this.buttonQuit = new System.Windows.Forms.Button();
            this.labelBaudRate = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.numericUpDownWriteTimeout = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownReadTimeout = new System.Windows.Forms.NumericUpDown();
            this.labelSec1 = new System.Windows.Forms.Label();
            this.labelSec2 = new System.Windows.Forms.Label();
            this.labelWriteTimeout = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelFile = new System.Windows.Forms.Label();
            this.textBoxFilePath = new System.Windows.Forms.TextBox();
            this.buttonSelectFile = new System.Windows.Forms.Button();
            this.groupBoxLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWriteTimeout)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownReadTimeout)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonSend
            // 
            this.buttonSend.Location = new System.Drawing.Point(15, 489);
            this.buttonSend.Name = "buttonSend";
            this.buttonSend.Size = new System.Drawing.Size(75, 23);
            this.buttonSend.TabIndex = 0;
            this.buttonSend.Text = "Print";
            this.buttonSend.UseVisualStyleBackColor = true;
            this.buttonSend.Click += new System.EventHandler(this.buttonSend_Click);
            // 
            // labelPort
            // 
            this.labelPort.AutoSize = true;
            this.labelPort.Location = new System.Drawing.Point(148, 266);
            this.labelPort.Name = "labelPort";
            this.labelPort.Size = new System.Drawing.Size(26, 12);
            this.labelPort.TabIndex = 10;
            this.labelPort.Text = "Port";
            // 
            // comboBoxPorts
            // 
            this.comboBoxPorts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPorts.FormattingEnabled = true;
            this.comboBoxPorts.Location = new System.Drawing.Point(244, 263);
            this.comboBoxPorts.Name = "comboBoxPorts";
            this.comboBoxPorts.Size = new System.Drawing.Size(121, 20);
            this.comboBoxPorts.TabIndex = 3;
            // 
            // groupBoxLog
            // 
            this.groupBoxLog.Controls.Add(this.buttonClear);
            this.groupBoxLog.Controls.Add(this.textBoxLog);
            this.groupBoxLog.Location = new System.Drawing.Point(15, 12);
            this.groupBoxLog.Name = "groupBoxLog";
            this.groupBoxLog.Size = new System.Drawing.Size(350, 198);
            this.groupBoxLog.TabIndex = 1;
            this.groupBoxLog.TabStop = false;
            this.groupBoxLog.Text = "Log";
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(278, 169);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(66, 23);
            this.buttonClear.TabIndex = 0;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // textBoxLog
            // 
            this.textBoxLog.Location = new System.Drawing.Point(6, 18);
            this.textBoxLog.Multiline = true;
            this.textBoxLog.Name = "textBoxLog";
            this.textBoxLog.ReadOnly = true;
            this.textBoxLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxLog.Size = new System.Drawing.Size(338, 145);
            this.textBoxLog.TabIndex = 0;
            this.textBoxLog.TabStop = false;
            // 
            // comboBoxFlowControl
            // 
            this.comboBoxFlowControl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFlowControl.FormattingEnabled = true;
            this.comboBoxFlowControl.Location = new System.Drawing.Point(244, 374);
            this.comboBoxFlowControl.Name = "comboBoxFlowControl";
            this.comboBoxFlowControl.Size = new System.Drawing.Size(121, 20);
            this.comboBoxFlowControl.TabIndex = 8;
            // 
            // labelFlowControl
            // 
            this.labelFlowControl.AutoSize = true;
            this.labelFlowControl.Location = new System.Drawing.Point(148, 377);
            this.labelFlowControl.Name = "labelFlowControl";
            this.labelFlowControl.Size = new System.Drawing.Size(70, 12);
            this.labelFlowControl.TabIndex = 15;
            this.labelFlowControl.Text = "Flow Control";
            // 
            // buttonQuit
            // 
            this.buttonQuit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonQuit.Location = new System.Drawing.Point(293, 489);
            this.buttonQuit.Name = "buttonQuit";
            this.buttonQuit.Size = new System.Drawing.Size(75, 23);
            this.buttonQuit.TabIndex = 16;
            this.buttonQuit.Text = "Exit";
            this.buttonQuit.UseVisualStyleBackColor = true;
            this.buttonQuit.Click += new System.EventHandler(this.buttonQuit_Click);
            // 
            // labelBaudRate
            // 
            this.labelBaudRate.AutoSize = true;
            this.labelBaudRate.Location = new System.Drawing.Point(148, 292);
            this.labelBaudRate.Name = "labelBaudRate";
            this.labelBaudRate.Size = new System.Drawing.Size(55, 12);
            this.labelBaudRate.TabIndex = 17;
            this.labelBaudRate.Text = "BaudRate";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(148, 314);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 18;
            this.label2.Text = "Parity";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(242, 292);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 12);
            this.label3.TabIndex = 19;
            this.label3.Text = "9600 bps";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(243, 314);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 12);
            this.label4.TabIndex = 20;
            this.label4.Text = "None";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(148, 335);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 12);
            this.label5.TabIndex = 21;
            this.label5.Text = "Data Bit";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(243, 335);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(11, 12);
            this.label6.TabIndex = 22;
            this.label6.Text = "8";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(149, 356);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 12);
            this.label7.TabIndex = 23;
            this.label7.Text = "Stop Bit";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(242, 356);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(11, 12);
            this.label8.TabIndex = 24;
            this.label8.Text = "1";
            // 
            // numericUpDownWriteTimeout
            // 
            this.numericUpDownWriteTimeout.Location = new System.Drawing.Point(244, 412);
            this.numericUpDownWriteTimeout.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.numericUpDownWriteTimeout.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownWriteTimeout.Name = "numericUpDownWriteTimeout";
            this.numericUpDownWriteTimeout.Size = new System.Drawing.Size(62, 19);
            this.numericUpDownWriteTimeout.TabIndex = 25;
            this.numericUpDownWriteTimeout.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // numericUpDownReadTimeout
            // 
            this.numericUpDownReadTimeout.Location = new System.Drawing.Point(245, 437);
            this.numericUpDownReadTimeout.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.numericUpDownReadTimeout.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownReadTimeout.Name = "numericUpDownReadTimeout";
            this.numericUpDownReadTimeout.Size = new System.Drawing.Size(61, 19);
            this.numericUpDownReadTimeout.TabIndex = 26;
            this.numericUpDownReadTimeout.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // labelSec1
            // 
            this.labelSec1.AutoSize = true;
            this.labelSec1.Location = new System.Drawing.Point(316, 414);
            this.labelSec1.Name = "labelSec1";
            this.labelSec1.Size = new System.Drawing.Size(31, 12);
            this.labelSec1.TabIndex = 27;
            this.labelSec1.Text = "[sec]";
            // 
            // labelSec2
            // 
            this.labelSec2.AutoSize = true;
            this.labelSec2.Location = new System.Drawing.Point(316, 439);
            this.labelSec2.Name = "labelSec2";
            this.labelSec2.Size = new System.Drawing.Size(31, 12);
            this.labelSec2.TabIndex = 28;
            this.labelSec2.Text = "[sec]";
            // 
            // labelWriteTimeout
            // 
            this.labelWriteTimeout.AutoSize = true;
            this.labelWriteTimeout.Location = new System.Drawing.Point(148, 414);
            this.labelWriteTimeout.Name = "labelWriteTimeout";
            this.labelWriteTimeout.Size = new System.Drawing.Size(76, 12);
            this.labelWriteTimeout.TabIndex = 29;
            this.labelWriteTimeout.Text = "Write Timeout";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(148, 439);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 12);
            this.label1.TabIndex = 30;
            this.label1.Text = "Read Timeout";
            // 
            // labelFile
            // 
            this.labelFile.AutoSize = true;
            this.labelFile.Location = new System.Drawing.Point(19, 241);
            this.labelFile.Name = "labelFile";
            this.labelFile.Size = new System.Drawing.Size(24, 12);
            this.labelFile.TabIndex = 31;
            this.labelFile.Text = "File";
            // 
            // textBoxFilePath
            // 
            this.textBoxFilePath.Location = new System.Drawing.Point(78, 238);
            this.textBoxFilePath.Name = "textBoxFilePath";
            this.textBoxFilePath.ReadOnly = true;
            this.textBoxFilePath.Size = new System.Drawing.Size(262, 19);
            this.textBoxFilePath.TabIndex = 32;
            // 
            // buttonSelectFile
            // 
            this.buttonSelectFile.Location = new System.Drawing.Point(346, 236);
            this.buttonSelectFile.Name = "buttonSelectFile";
            this.buttonSelectFile.Size = new System.Drawing.Size(19, 23);
            this.buttonSelectFile.TabIndex = 33;
            this.buttonSelectFile.Text = "...";
            this.buttonSelectFile.UseVisualStyleBackColor = true;
            this.buttonSelectFile.Click += new System.EventHandler(this.buttonSelectFile_Click);
            // 
            // MainForm
            // 
            this.AcceptButton = this.buttonSend;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonQuit;
            this.ClientSize = new System.Drawing.Size(377, 524);
            this.Controls.Add(this.buttonSelectFile);
            this.Controls.Add(this.textBoxFilePath);
            this.Controls.Add(this.labelFile);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelWriteTimeout);
            this.Controls.Add(this.labelSec2);
            this.Controls.Add(this.labelSec1);
            this.Controls.Add(this.numericUpDownReadTimeout);
            this.Controls.Add(this.numericUpDownWriteTimeout);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelBaudRate);
            this.Controls.Add(this.buttonQuit);
            this.Controls.Add(this.labelFlowControl);
            this.Controls.Add(this.comboBoxFlowControl);
            this.Controls.Add(this.groupBoxLog);
            this.Controls.Add(this.comboBoxPorts);
            this.Controls.Add(this.labelPort);
            this.Controls.Add(this.buttonSend);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.ShowIcon = false;
            this.Text = "Virtual Serial Port Sample";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.groupBoxLog.ResumeLayout(false);
            this.groupBoxLog.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWriteTimeout)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownReadTimeout)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonSend;
        private System.Windows.Forms.Label labelPort;
        private System.Windows.Forms.ComboBox comboBoxPorts;
        private System.Windows.Forms.GroupBox groupBoxLog;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.TextBox textBoxLog;
        private System.Windows.Forms.ComboBox comboBoxFlowControl;
        private System.Windows.Forms.Label labelFlowControl;
        private System.Windows.Forms.Button buttonQuit;
        private System.Windows.Forms.Label labelBaudRate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown numericUpDownWriteTimeout;
        private System.Windows.Forms.NumericUpDown numericUpDownReadTimeout;
        private System.Windows.Forms.Label labelSec1;
        private System.Windows.Forms.Label labelSec2;
        private System.Windows.Forms.Label labelWriteTimeout;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelFile;
        private System.Windows.Forms.TextBox textBoxFilePath;
        private System.Windows.Forms.Button buttonSelectFile;
    }
}

